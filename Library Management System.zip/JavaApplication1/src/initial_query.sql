
create database libsis;
use libsis;

create table login_info ( user varchar(50) primary key, pass varchar(50) );
insert into login_info values("admin", "admin123");
create table personal_info(user varchar(50) primary key, fname varchar(50), lname varchar(50), email varchar(50), contact varchar(50), address varchar(50));
	create table student_info (registration varchar(50) primary key, fname varchar(50), lname varchar(50),
 branch varchar(50), email varchar(50), address varchar(50), contact varchar(50), date varchar(50));
create table books (id varchar(50) primary key, name varchar(50), author varchar(50), publisher varchar(50),
date varchar(50));
create table avail_books (id varchar(50) primary key, quantity integer);
create table issued_books (id varchar(50), sid varchar(50), date varchar(50), primary key (id, sid), 
foreign key (sid) references student_info(registration), foreign key(id) references books(id));