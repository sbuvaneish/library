/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Bhuvanesh
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        
        c1.set(2011, 04, 03);
        c2.set(2012, 04, 04);
        
        long m1 = c1.getTimeInMillis();
        long m2 = c2.getTimeInMillis();
        
        long dif = m2 - m1;
        
        long days = dif / (24 * 60 * 60 * 1000);
        
        System.out.println(days);
        
    }
    
}
