/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author Bhuvanesh
 */

class my_thread extends Thread
{
    Socket s;
    Statement stmt;
    
    my_thread(Socket t, Statement st)
    {
        s = t;
        stmt = st;
    }
    
    public synchronized void run()
    {
        try {
            
            ObjectInputStream oin = new ObjectInputStream(s.getInputStream());
            librarian.user_object userob = (librarian.user_object) oin.readObject();
            
            String username = userob.username, password = userob.password;
            
            String query = "select * from login_info where user = '" + username + "'";
            
            ResultSet rs = stmt.executeQuery(query);
            
            String result = "";
            
            if(rs.next())
            {
                result = "Username not available";
            }
            else
            {
                query = "insert into login_info values ('" + username + "', '" + password + "')";
                stmt.executeUpdate(query);
                
                query = "insert into personal_info values ('" + username + "', '" + userob.first_name + "', '" + userob.last_name + "', '" + userob.email + "', '" + userob.contact + "', '" + userob.address + "')" ; 
                stmt.executeUpdate(query);
                
                result = "Registration Successful";
            }
            
            ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
            
            oout.writeObject(result);
            
        } catch (IOException ex) {
            Logger.getLogger(my_thread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(my_thread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(my_thread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

public class register_lib {
    
    public static void main(String args[]) throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libsis", "root", "admin");
        Statement stmt = conn.createStatement();
        
        try {
            
            ServerSocket ss = new ServerSocket(6002);
            
            Socket s;
            my_thread t;
            
            System.out.println("check 2");
            
            while(true)
            {
                s = ss.accept();
                t = new my_thread(s, stmt);
                t.start();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(register_lib.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
