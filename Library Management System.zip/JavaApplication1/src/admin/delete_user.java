/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bhuvanesh
 */

class my_thread2 extends Thread
{
    Socket s;
    Statement stmt;
    
    my_thread2(Socket t, Statement st)
    {
        s = t;
        stmt = st;
    }
    
    public synchronized void run()
    {
        try {
            
            ObjectInputStream oin = new ObjectInputStream(s.getInputStream());
            
            String username = (String) oin.readObject();
            
            String query = "delete from login_info where user = '" + username + "'";
            stmt.executeUpdate(query);
            
            query = "delete from personal_info where user = '" + username + "'";
            stmt.executeUpdate(query);
            
            String result = "Successful";
            
            ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
            
            oout.writeObject(result);
            
            
            
        } catch (IOException ex) {
            Logger.getLogger(my_thread2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(my_thread2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(my_thread2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


public class delete_user {
    
    public static void main(String args[]) throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libsis", "root", "admin");
        Statement stmt = conn.createStatement();
        
        
        try {
            
            ServerSocket ss = new ServerSocket(6003);
            
            Socket s;
            my_thread2 t;
            
            System.out.println("check 2");
            
            while(true)
            {
                s = ss.accept();
                t = new my_thread2(s, stmt);
                t.start();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(delete_user.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
