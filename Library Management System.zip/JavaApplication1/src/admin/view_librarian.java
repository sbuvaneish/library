/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;

/**
 *
 * @author Bhuvanesh
 */


class my_thread3 extends Thread
{
    Socket s;
    Statement stmt;
    
    my_thread3(Socket t, Statement st)
    {
        s = t;
        stmt = st;
    }
    
    public synchronized void run()
    {
        try {
            
            ObjectInputStream oin = new ObjectInputStream(s.getInputStream());
            
            String temp = (String) oin.readObject();
            
            String query = "select * from personal_info";
            
            ResultSet rs = stmt.executeQuery(query);
            
            Vector v = new Vector();
            
            while(rs.next())
            {
                Vector t = new Vector();
                
                for(int i=1; i<7; i++)
                {
                    t.add(rs.getString(i));
                }
                
                v.add(t);
            }
            
            Vector col = new Vector();
            
            col.add("user");
            col.add("fname");
            col.add("lname");
            col.add("email");
            col.add("contact");
            col.add("address");
            
            JTable table = new JTable(v, col);
            
            ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
            
            oout.writeObject(table);
            
            oout.flush();
            
            
        } catch (IOException ex) {
            Logger.getLogger(my_thread3.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(my_thread3.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(my_thread3.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


public class view_librarian {
    
    public static void main(String args[]) throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libsis", "root", "admin");
        Statement stmt = conn.createStatement();
        
        
        try {
            
            ServerSocket ss = new ServerSocket(6004);
            
            Socket s;
            my_thread3 t;
            
            System.out.println("check 2");
            
            while(true)
            {
                s = ss.accept();
                t = new my_thread3(s, stmt);
                t.start();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(view_librarian.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
