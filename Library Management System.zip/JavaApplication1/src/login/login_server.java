/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.sql.Statement;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import static java.lang.Class.forName;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bhuvanesh
 */

class my_thread extends Thread
{
    Socket s;
    Statement stmt;
    
    String username, password;
    
    my_thread(Socket t, Statement st)
    {
        System.out.println("constructor of thread");
        s = t;
        stmt = st;
    }
    
    public synchronized void run()
    {
        try {
            
            System.out.println("inside run method");
            
            ObjectInputStream oin = new ObjectInputStream(s.getInputStream());
            
            login_object lobj;
            
            if(true)
            {
                System.out.println("check 3");
                
                lobj = (login_object) oin.readObject();
                username = lobj.username;
                password = lobj.password;
                
                //oin.close();
                
                String query = "select pass from login_info where user = '" + String.valueOf(username) + "'";
                
                ResultSet rs = stmt.executeQuery(query);
                
                String result = "";
                
                System.out.println(password);
                
                if(rs.next())
                {
                    String compare = rs.getString("pass");
                    
                    System.out.println(compare);
                    System.out.println(password);
                    
                    if(compare.equals(password))
                    {
                        result= "true";
                    }
                    else
                    {
                        result = "Invalid Credentials";
                    }
                }
                else
                {
                    result = "Get yourself registered with the admin";
                }
                
                System.out.println(result);
                
                ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
                oout.writeObject(result);
                oout.flush();
                //oout.close();
            }
            
            //s.close();
            
        } catch (IOException ex) {
            Logger.getLogger(my_thread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(my_thread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(my_thread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


public class login_server {
    
    public static void main(String args[]) throws ClassNotFoundException, SQLException
    {
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libsis", "root", "admin");
        Statement stmt = conn.createStatement();
        
        try {
            
            ServerSocket ss = new ServerSocket(6001);
            
            Socket s;
            my_thread t;
            
            System.out.println("check 2");
            
            while(true)
            {
                s = ss.accept();
                t = new my_thread(s, stmt);
                t.start();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(login_server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
