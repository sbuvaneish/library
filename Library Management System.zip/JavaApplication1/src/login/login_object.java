/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.io.Serializable;

/**
 *
 * @author Bhuvanesh
 */
public class login_object implements Serializable{
    
    String username, password;
    
    login_object(String user, String pass)
    {
        username = user;
        password = pass;
    }
    
}
