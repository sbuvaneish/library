/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarian;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bhuvanesh
 */

class my_thread extends Thread
{
    Socket s;
    Statement stmt;
    
    my_thread(Socket t, Statement st)
    {
        s = t;
        stmt = st;
    }
    
    public synchronized void run()
    {
        try {
            
            ObjectInputStream oin = new ObjectInputStream(s.getInputStream());
            student userob = (student) oin.readObject();
            
            String query = "select * from student_info where registration = '" + userob.registration + "'";
            
            ResultSet rs = stmt.executeQuery(query);
            
            String result = "";
            
            if(rs.next())
            {
                result = "Student already registered";
            }
            else
            {
                
                Date date = new Date();
        
                SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy");
        
                String datestr = f.format(date);
                
                query = "insert into student_info values ('" + userob.registration + "', '" + userob.first_name
                        + "', '"  + userob.last_name + "', '" + userob.branch + "', '" + userob.email + 
                        "', '" + userob.address + "', '" + userob.contact + "', '" + datestr + "')";
                
                stmt.executeUpdate(query);
                
                result = "registration successful";
            }
            
            ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
            
            oout.writeObject(result);
            
        } catch (IOException ex) {
            Logger.getLogger(my_thread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(my_thread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(my_thread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


public class register_stud_server {
    
    public static void main(String args[]) throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libsis", "root", "admin");
        Statement stmt = conn.createStatement();
        
        try {
            
            ServerSocket ss = new ServerSocket(6005);
            
            Socket s;
            my_thread t;
            
            System.out.println("check 2");
            
            while(true)
            {
                s = ss.accept();
                t = new my_thread(s, stmt);
                t.start();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(register_stud_server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
