/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarian;

import java.io.Serializable;

/**
 *
 * @author Bhuvanesh
 */
public class book_object implements Serializable{
    
    String book_id, name, author, publisher, student_id;
    int type, quantity;
    
    public book_object(String bid, String n, String a, String p, int q)
    {
        type = 1;
        book_id = bid;
        name = n;
        author = a;
        publisher = p;
        quantity = q;
    }
    
    public book_object(String bid, String sid)
    {
        type = 2;
        book_id = bid;
        student_id = sid;
    }
    
    public book_object(String bid, String sid, int t)
    {
        type = 3;
        book_id = bid;
        student_id = sid;
    }
    
}
