/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarian;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;

/**
 *
 * @author Bhuvanesh
 */

class my_thread3 extends Thread
{
    Socket s;
    Statement stmt;
    
    my_thread3(Socket t, Statement st)
    {
        s = t;
        stmt = st;
    }
    
    public synchronized void run()
    {
        try {
            
            ObjectInputStream oin = new ObjectInputStream(s.getInputStream());
            String option = (String) oin.readObject();
            
            String query;
            
            Vector v = new Vector();
            
            Vector col = new Vector();
            
            ResultSet rs;
            
            if(option.equals("Available"))
            {
                query = "select * from books natural join avail_books";
                rs = stmt.executeQuery(query);
                
                while(rs.next())
                {
                    Vector row = new Vector();
                    for(int i=1; i<6; i++)
                    {
                        row.add(rs.getString(i));
                    }
                    row.add(rs.getInt(6));
                    
                    v.add(row);
                }
                
                col.add("id");
                col.add("name");
                col.add("author");
                col.add("publisher");
                col.add("date");
                col.add("quantity");
                
            }
            else
            {
                query = "select b.id, b.name, b.author, b.publisher, i.sid, i.date from books b join issued_books i on b.id = i.id";
                rs = stmt.executeQuery(query);
                
                while(rs.next())
                {
                    Vector row = new Vector();
                    for(int i=1; i<7; i++)
                    {
                        row.add(rs.getString(i));
                    }
                    
                    v.add(row);
                }
                
                col.add("id");
                col.add("name");
                col.add("author");
                col.add("publisher");
                col.add("reg_no");
                col.add("date");
            }
            
            JTable table = new JTable(v, col);
            
            ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
            
            oout.writeObject(table);
            
        } catch (IOException ex) {
            Logger.getLogger(my_thread3.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(my_thread3.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(my_thread3.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


public class view_server {
    
    public static void main(String args[]) throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libsis", "root", "admin");
        Statement stmt = conn.createStatement();
        
        try {
            
            ServerSocket ss = new ServerSocket(6007);
            
            Socket s;
            my_thread3 t;
            
            System.out.println("check 2");
            
            while(true)
            {
                s = ss.accept();
                t = new my_thread3(s, stmt);
                t.start();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(view_server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
