/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarian;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bhuvanesh
 */


class my_thread2 extends Thread
{
    Socket s;
    Statement stmt;
    
    my_thread2(Socket t, Statement st)
    {
        s = t;
        stmt = st;
    }
    
    public synchronized void run()
    {
        try {
            
            ObjectInputStream oin = new ObjectInputStream(s.getInputStream());
            
            book_object book = (book_object) oin.readObject();
            
            String query;
            
            ResultSet rs;
            
            String result = "";
            
            Date date = new Date();
        
            SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy");
        
            String datestr = f.format(date);
            
            if(book.type == 1)
            {
                query = "select * from books where id = '" + book.book_id + "'";
                rs = stmt.executeQuery(query);
                
                if(!rs.next())
                {
                    query = "insert into books values ('" + book.book_id + "', '" + book.name + "', '"
                            + book.author + "', '" + book.publisher + "', '" + datestr + "')";
                    stmt.executeUpdate(query);
                }
                
                query = "select quantity from avail_books where id = '" + book.book_id + "'";
                rs = stmt.executeQuery(query);
                
                if(rs.next())
                {
                    int quant = rs.getInt(1);
                    quant += book.quantity;
                    
                    query = "update avail_books set quantity = " + String.valueOf(quant) + " where id = '"
                            + book.book_id + "'";
                    
                    stmt.executeUpdate(query);
                    
                }
                else
                {
                    query = "insert into avail_books values ('" + book.book_id + "', " + 
                            String.valueOf(book.quantity) + ")";
                    stmt.executeUpdate(query);
                }
                
                result = "books added successfully";
            }
            else if(book.type == 2)
            {
                 query = "select * from student_info where registration = '" + book.student_id + "'";
                 rs = stmt.executeQuery(query);
                 
                 if(!rs.next())
                 {
                     result = "student is not registered";
                 }
                 else
                 {
                     query = "select quantity from avail_books where id = '" + book.book_id + "'";
                     rs = stmt.executeQuery(query);
                     
                     
                     if(rs.next())
                     {
                         int quant = rs.getInt(1);
                         
                         query = "select * from issued_books where id = '" + book.book_id + "' and sid = '" + 
                                 book.student_id + "'";
                         
                         rs = stmt.executeQuery(query);
                         
                         if(rs.next())
                         {
                             result = "student " + book.student_id + " already has a copy of the book " + 
                                     book.book_id;
                         }
                         else
                         {

                            if(quant > 1)
                            {
                                quant--;
                                query = "update avail_books set quantity = " + String.valueOf(quant) + " where id = '"
                               + book.book_id + "'";

                                stmt.executeUpdate(query);
                            }
                            else
                            {
                                query = "delete from avail_books where id = '" + book.book_id + "'";
                                stmt.executeUpdate(query);
                            }

                            query = "insert into issued_books values ('" + book.book_id + "', '" + book.student_id
                                     + "', '" + datestr + "')";

                            stmt.executeUpdate(query);

                            result = "Successfully updated";
                            
                         }
                     }
                     else
                     {
                         result = "book not available";
                     }
                 }
            }
            else if(book.type == 3)
            {
                 
                 query = "select date from issued_books where id = '" + book.book_id + "' and sid = '" + 
                                 book.student_id + "'";
                 
                 rs = stmt.executeQuery(query);
                 
                 
                 String dt = "";
                 
                 
                 if(rs.next())
                 {
                     dt = rs.getString(1);
                
                    query = "delete from issued_books where id = '" + book.book_id + "' and sid = '" + 
                                    book.student_id + "'";
                    stmt.executeUpdate(query);

                    query = "select quantity from avail_books where id = '" + book.book_id + "'";
                    rs = stmt.executeQuery(query);

                   if(rs.next())
                   {
                       int quant = rs.getInt(1);
                       quant++;

                       query = "update avail_books set quantity = " + String.valueOf(quant) + " where id = '"
                               + book.book_id + "'";

                       stmt.executeUpdate(query);

                   }
                   else
                   {
                       query = "insert into avail_books values ('" + book.book_id + "', 1)";
                       stmt.executeUpdate(query);
                   }

                   result = "Successfully updated";
                   
                   int year2 = Integer.parseInt(datestr.substring(6, 10));
                   int year1 = Integer.parseInt(dt.substring(6, 10));
                   int month2 = Integer.parseInt(datestr.substring(3, 5));
                   int month1 = Integer.parseInt(dt.substring(3, 5));
                   int day2 = Integer.parseInt(datestr.substring(0, 2));
                   int day1 = Integer.parseInt(dt.substring(0, 2));
                   
                   Calendar c1 = Calendar.getInstance();
                   Calendar c2 = Calendar.getInstance();
                   
                   
                   System.out.println(day1 + "-" + month1 + "-" + year1);
                   System.out.println(day2 + "-" + month2 + "-" + year2);
                   
                    c1.set(year1, month1, day1);
                    c2.set(year2, month2, day2);

                    long m1 = c1.getTimeInMillis();
                    long m2 = c2.getTimeInMillis();

                    long dif = m2 - m1;

                    long days = dif / (24 * 60 * 60 * 1000);
                    
                    System.out.println(days);
                    
                    result += "\nReturned after " + String.valueOf(days) + " days";
                   
                 }
                 else
                 {
                     result = "Unable to process request\n No entry found for this id pair";
                 }
            }
            
            ObjectOutputStream oout = new ObjectOutputStream(s.getOutputStream());
            
            oout.writeObject(result);
            
            oout.flush();
            
        } catch (IOException ex) {
            Logger.getLogger(my_thread2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(my_thread2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(my_thread2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


public class book_server {
    
    public static void main(String args[]) throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libsis", "root", "admin");
        Statement stmt = conn.createStatement();
        
        try {
            
            ServerSocket ss = new ServerSocket(6006);
            
            Socket s;
            my_thread2 t;
            
            System.out.println("check 2");
            
            while(true)
            {
                s = ss.accept();
                t = new my_thread2(s, stmt);
                t.start();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(book_server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
