/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarian;

import java.io.Serializable;

/**
 *
 * @author Bhuvanesh
 */
public class student implements Serializable{
   
    String registration, first_name, last_name, branch, email, address, contact;
   
    public student(String r, String f, String l, String b, String e, String a, String c)
    {
        registration = r;
        first_name = f;
        last_name = l;
        branch = b;
        email = e;
        address = a;
        contact = c;
    }
    
}
