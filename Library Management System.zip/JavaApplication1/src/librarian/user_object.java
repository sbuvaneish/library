/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarian;

import java.io.Serializable;

/**
 *
 * @author Bhuvanesh
 */
public class user_object implements Serializable{
    
    public String first_name, last_name, email, contact, address, username, password;
    
    public user_object(String f, String l, String e, String c, String a, String u, String p)
    {
        first_name = f;
        last_name = l;
        email = e;
        contact = c;
        address = a;
        username = u;
        password = p;
    }
    
}
